document.addEventListener('DOMContentLoaded', function () {
    const listaMensajes = document.getElementById('listaMensajes');
    const publicarBtn = document.getElementById('publicarMensaje');
    const nombreInput = document.getElementById('nombre');
    const apellidosInput = document.getElementById('apellidos');
    const emailInput = document.getElementById('email');
    const mensajeTexto = document.getElementById('mensajeTexto');

    // Función para cargar mensajes desde localStorage
    const cargarMensajes = () => {
        const mensajes = JSON.parse(localStorage.getItem('foroMensajes')) || [];
        listaMensajes.innerHTML = '';
        mensajes.forEach((mensaje, index) => {
            const div = document.createElement('div');
            div.classList.add('mensaje');
            div.innerHTML = `
                <p><strong>${mensaje.nombre} ${mensaje.apellidos}</strong> (${mensaje.email})</p>
                <p>${mensaje.texto}</p>
                <small>Publicado el: ${mensaje.fecha}</small>
                <button onclick="eliminarMensaje(${index})">Eliminar</button>
            `;
            listaMensajes.appendChild(div);
        });
    };

    // Función para publicar un mensaje
    publicarBtn.addEventListener('click', () => {
        const nombre = nombreInput.value.trim();
        const apellidos = apellidosInput.value.trim();
        const email = emailInput.value.trim();
        const texto = mensajeTexto.value.trim();

        if (!nombre || !apellidos || !email || !texto) {
            alert('Por favor, completa todos los campos antes de publicar.');
            return;
        }

        if (!/\S+@\S+\.\S+/.test(email)) {
            alert('Por favor, introduce un email válido.');
            return;
        }

        const mensajes = JSON.parse(localStorage.getItem('foroMensajes')) || [];
        const nuevoMensaje = {
            nombre: nombre,
            apellidos: apellidos,
            email: email,
            texto: texto,
            fecha: new Date().toLocaleString()
        };
        mensajes.push(nuevoMensaje);
        localStorage.setItem('foroMensajes', JSON.stringify(mensajes));

        // Limpiar campos
        nombreInput.value = '';
        apellidosInput.value = '';
        emailInput.value = '';
        mensajeTexto.value = '';

        // Recargar mensajes
        cargarMensajes();
    });

    // Función para eliminar un mensaje
    window.eliminarMensaje = (index) => {
        const mensajes = JSON.parse(localStorage.getItem('foroMensajes')) || [];
        mensajes.splice(index, 1); // Elimina el mensaje en la posición indicada
        localStorage.setItem('foroMensajes', JSON.stringify(mensajes));
        cargarMensajes(); // Actualiza la lista de mensajes
    };

    // Inicializar el foro cargando mensajes previos
    cargarMensajes();
});