//-- Variables.
var videosIDvod =
[
    "https://www.youtube.com/embed/CkVXbU-PNRs",
    "https://www.youtube.com/embed/d9OFM7m3cVo",
    "https://www.youtube.com/embed/xH1u4CKHgxw",
    "https://www.youtube.com/embed/wgiBStujBCw",
    "https://www.youtube.com/embed/7jp7_KWHmJw",
    "https://www.youtube.com/embed/FURv94-avkA",
    "https://www.youtube.com/embed/9sCVcWD1Svs",
    "https://www.youtube.com/embed/OkqimKmgMR8"
];
var contenidoBajoDemanda = document.getElementById('contenidoVoD');

function mostrarVoD() {
    
    contenidoBajoDemanda.innerHTML = "";
    videosIDvod.forEach(auxVoD => {
        var iframeVoD = document.createElement("iframe");
        iframeVoD.src =  auxVoD;
        iframeVoD.width = "400";
        iframeVoD.height = "250";
        iframeVoD.setAttribute("allow", "autoplay");
        iframeVoD.setAttribute("allowFullscreen", "false");
        contenidoBajoDemanda.appendChild(iframeVoD);
    });
}

//-- Punto de inicio del programa.
mostrarVoD();