//-- Variables.
var tituloQueEs = document.getElementById("btnQueEs");
var contenidoQueEs = document.getElementById("abrirQueEs");

var tituloBot = document.getElementById("btnBot");
var contenidoBot = document.getElementById("abrirBot");

var tituloVoD = document.getElementById("btnVoD");
var contenidoVoD = document.getElementById("abrirVoD");

var tituloForo = document.getElementById("btnForo");
var contenidoForo = document.getElementById("abrirForo");

var tituloSurgimiento = document.getElementById("btnSurgimiento");
var contenidoSurgimiento = document.getElementById("abrirSurgimiento");

var tituloDonde = document.getElementById("btnDonde");
var contenidoDonde = document.getElementById("abrirDonde");

var tituloContact = document.getElementById("btnContact");
var contenidoContact = document.getElementById("abrirContact");

//-- Ocultarlo inicialmente.
contenidoQueEs.classList.add("oculto");
contenidoBot.classList.add("oculto");
contenidoVoD.classList.add("oculto");
contenidoForo.classList.add("oculto");
contenidoSurgimiento.classList.add("oculto");
contenidoDonde.classList.add("oculto");
contenidoContact.classList.add("oculto");

//-- Acción de ocultar/desplegar contenido.
function despliegAsigHack(contenido) {
    contenido.classList.toggle("oculto");
}

//-- Acción de darle click al módulo en específico.
tituloQueEs.addEventListener("click", () => {
    despliegAsigHack(contenidoQueEs);
});
tituloBot.addEventListener("click", () => {
    despliegAsigHack(contenidoBot);
});
tituloVoD.addEventListener("click", () => {
    despliegAsigHack(contenidoVoD);
});
tituloForo.addEventListener("click", () => {
    despliegAsigHack(contenidoForo);
});
tituloSurgimiento.addEventListener("click", () => {
    despliegAsigHack(contenidoSurgimiento);
});
tituloDonde.addEventListener("click", () => {
    despliegAsigHack(contenidoDonde);
});
tituloContact.addEventListener("click", () => {
    despliegAsigHack(contenidoContact);
});